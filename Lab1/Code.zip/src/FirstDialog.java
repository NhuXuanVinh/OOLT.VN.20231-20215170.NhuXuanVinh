import javax.swing.JOptionPane;
// Nhu Xuan Vinh 20215170
public class FirstDialog{
    public static void main(String[] args){
        JOptionPane.showMessageDialog(null, "Hello, how are you");
        System.exit(0);
    }
}