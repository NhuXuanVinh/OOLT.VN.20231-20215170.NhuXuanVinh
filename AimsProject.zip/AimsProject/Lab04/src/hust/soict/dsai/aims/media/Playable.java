package hust.soict.dsai.aims.media;


//Chu Đình Hiển - 20215046 - Tạo interface Playable
public interface Playable {
	//Tạo phương thức play
	public void play();
}
